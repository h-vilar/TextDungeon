import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static Scanner sc;
    private static void TextDungeon() {

        /* na hora de começar a batalha, um inimigo aleatorio da lista de inimigos vai ser
        selecionado. por isso que não pode adicionar o boss nessa lista; vai ter uma outra
        lista pra selecionar um dos bosses aleatoriamente na parte do gameloop que tiver
        que ser o boss.
         */
        ArrayList<Enemy> inimigos = new ArrayList<>();
        KirinDragon kirin = new KirinDragon();
        inimigos.add(kirin);

        ArrayList<Jogador> herois = new ArrayList<>();
        Fairy fada = new Fairy(100, "Fada");
        Sasquatch pe = new Sasquatch(100, "Pe Grande");
        Geni g = new Geni(100, "Geni");
        herois.add(fada);
        herois.add(pe);
        herois.add(g);

        // ^^^ pré configuração ^^^
        // texto e arte de intro

        //(deixar tudo amarelo pra depois ver as cores)
        System.out.println(Cores.AMARELO_intro);

        //antes/entre as batalhas, gostaria que o texto viesse lento
        //(uns 60 millis) para dar um contraste com a sensação de ação x calmaria.

        Historia.placeholder();

        TextDungeon.escrever("   Player 1, escolha seu herói: \n\n\n", 60);
        for(int i = 0; i<herois.size(); i++){
            System.out.printf((i+1)+") ");
            TextDungeon.escrever(herois.get(i).nome, 60);
            System.out.printf("\n");
            TextDungeon.escrever(herois.get(i).sinopse, 60);
        }
        int n1 = opcao(1, herois.size());
        Jogador P1 = herois.remove(n1 - 1); // o jogador vê 1, 2, 3...; a lista começa em 0

        TextDungeon.escrever("\n   Player 2, escolha seu herói: \n\n\n", 60);
        for(int i = 0; i<herois.size(); i++){
            System.out.printf((i+1)+") ");
            TextDungeon.escrever(herois.get(i).nome, 60);
            System.out.printf("\n");
            TextDungeon.escrever(herois.get(i).sinopse, 60);
        }
        int n2 = opcao(1, herois.size());
        Jogador P2 = herois.remove(n2 - 1);

        TextDungeon.clean();
        Historia.placeholder();

        Enemy Enemy1 = inimigos.remove(Jogo.criarNumeroAleatorio(inimigos.size()));














        //Demo.demo(); //ainda to editando as coisas dentro do demo que é mais rapido,
        //mas já já ponho o real inicio aqui (classe historia.art, .intro, e aí o menu de escolha de personagens.)

        /*em algum lugar, vai ficar uma coisa tipo:
        (dentro da função de batalha)

        TextDungeon.escrever(Enemy.intro, Enemy.drama);
         */

        System.out.printf("\n\n\nFim");
    }

    public static void main(String[] args) {

        //TextDungeon(); //pra provar que o console pane é apenas um capricho e o jogo é o mesmo sem ele

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("TextDungeon");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(new ConsolePane());
            frame.setSize(900, 1000);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            //thread separada p/ não travar a EDT
            new Thread(Main::TextDungeon).start();
        });

    }

    /** Lê um número de min a max (inclusive). Repete até o jogador digitar algo válido. */
    public static int opcao(int min, int max) {
        if (sc == null) sc = new Scanner(System.in);   // criado só no primeiro uso
        while (true) {
            String linha = sc.nextLine().trim();
            try {
                int n = Integer.parseInt(linha);
                if (n >= min && n <= max) return n;
            } catch (NumberFormatException e) { }
            System.out.println("Escolha uma das opções! (de " + min + " a " + max + ".)");
        }
    }


    /*Inicialização: Com as classes base criadas, podemos programar o jogo! No início
    do programa, chame o mét0do iniciarJogo(). Esse mét0do deve definir o
    número de jogadores, que corresponde ao tamanho do ArrayList retornado. Em
    seguida, ainda no mét0do iniciarJogo(), exiba na tela uma mensagem de
    boas-vindas, apresentando o nome, idade, descrição e a regra modificada de cada
    personagem por meio do mét0do contarHistoria() definido na classe de cada
    Personagem. Por fim, permita que cada jogador escolha um personagem exclusivo,
    utilizando o mét0do setPersonagem(), e instancie cada personagem selecionado.

    Finalização: Quem ganhou? Determine o vencedor com base nos dados de
    pontuacao() e exiba a mensagem apropriada para cada possível final.*/
}