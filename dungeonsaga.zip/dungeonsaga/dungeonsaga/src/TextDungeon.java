import java.util.ArrayList;

public class TextDungeon implements Jogo {

    public static void escrever(String texto, long millis){ //maquina de escrever
        for (Character c : texto.toCharArray()) {
            System.out.print(c);
            if (!Character.isWhitespace(c)) {
                try {
                    Thread.sleep(millis); //5,10,20,30 são bons
                } catch (Exception _) {}
            }
        }
    }

    static void clean() {
        System.out.print("\033[H\033[2J"); System.out.flush();}

    @Override
    public ArrayList<Jogador> iniciarjogo() {
        return null;
    }

    @Override
    public void jogarTurno(Jogador jogador) {

    }

    @Override
    public boolean jogoAcabou() {
        return false;
    }

    //ughhhhhh.
    void pontuacao(){}

}
