public class Item {

    String nome;

}
