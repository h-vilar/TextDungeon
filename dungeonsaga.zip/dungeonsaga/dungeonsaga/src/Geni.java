public class Geni extends Jogador {

    final int maxhp;
    int hp;

    public Geni(int maxhp, String nome){
        this.nome = nome;
        this.maxhp = maxhp;
        this.hp = maxhp;
        sinopse = "um genio\n\n";

    }

    //apresenta as características dos personagens
    //(nome, descrição, idade) e qual regra modifica.
    void contarHistoria(){

    }

    //mét0dos para reescrever a regra a
    //ser aplicada para o Jogador em questão.
    void adicionaRegra(){

    }
    void modificaRegra() {

    }
    void sorteiaRegra(){

    }

    @Override
    void habilidade1() {

    }

    @Override
    void habilidade2() {

    }

    @Override
    void habilidade3() {

    }

    @Override
    void habilidade4() {

    }

    @Override
    void habilidade5() {

    }
}
