public class Fairy extends Jogador {

    final int maxhp;
    int hp;


    public Fairy(int maxhp, String nome){
        this.nome = nome;
        this.maxhp = maxhp;
        this.hp = maxhp;
        sinopse = "uma fadinha que voa\n\n";

    }

    //apresenta as características dos personagens
    //(nome, descrição, idade) e qual regra modifica.
    // (antigo contarHistoria()


    //mét0dos para reescrever a regra a
    //ser aplicada para o Jogador em questão.
    void adicionaRegra(){

    }
    void modificaRegra() {

    }
    void sorteiaRegra(){

    }

    @Override
    void habilidade1() {

    }

    @Override
    void habilidade2() {

    }

    @Override
    void habilidade3() {

    }

    @Override
    void habilidade4() {

    }

    @Override
    void habilidade5() {

    }
}
