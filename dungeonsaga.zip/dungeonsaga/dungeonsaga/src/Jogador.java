public abstract class Jogador {

    int maxhp;
    int hp;
    String sinopse;
    String nome;
    //escolhe o personagem de
    //cada jogador, onde idPersonagem indica o id do personagem. Se um
    //personagem já foi escolhido, os outros jogadores não podem escolher
    //o mesmo personagem.
    public void setPersonagem(int idPersonagem){

    }

    abstract void habilidade1(Enemy enemy, Jogador aliado);
    abstract void habilidade2();
    abstract void habilidade3();
    abstract void habilidade4();
    abstract void habilidade5();







    //métod para que o jogador defina a
    //estratégia (jogada) a ser utilizada de acordo com as condições atuais
    //do jogo.
    public void pensarEstrategia(){

    }

    //méthodo para aplicar a estratégia escolhida
    //no méthodo anterior, atualizando itens como ficaria o tabuleiro ou o
    //estado do outro jogador.
    public void aplicarEstrategia(){

    }


    public abstract void options();
}
