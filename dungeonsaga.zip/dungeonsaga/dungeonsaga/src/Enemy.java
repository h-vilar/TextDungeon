public class Enemy {

    public final int maxhp = 100;
    int hp = maxhp;

    long drama = 10; //tempo pras descrições desse inimigo escreverem.

    boolean Airborne; //se é aéreo ou está no ar agora~
    boolean Waterlog; //se está na água ou molhado agora~

    boolean Fiery;
    boolean Fragile; //+ afetado por tremor
    boolean Reflexive; //anti-projétil
    boolean Toxic; //anti-melee
    boolean AntiPhysic; //imune a dano físico
    boolean AntiMagic; //imune a dano mágico

}
