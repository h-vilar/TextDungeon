public class Sasquatch extends Jogador {

    public Sasquatch(int maxhp, String nome){
        this.maxhp = maxhp;
        this.nome = nome;
        this.hp = maxhp;
        sinopse = "um monstro gigante\n\n";
    }

    //apresenta as características dos personagens
    //(nome, descrição, idade) e qual regra modifica.


    //mét0dos para reescrever a regra a
    //ser aplicada para o Jogador em questão.
    void adicionaRegra(){

    }
    void modificaRegra() {

    }
    void sorteiaRegra(){

    }

    @Override
    void habilidade1(Enemy enemy, Jogador aliado) {

    }

    @Override
    void habilidade2() {

    }

    @Override
    void habilidade3() {

    }

    @Override
    void habilidade4() {

    }

    @Override
    void habilidade5() {

    }

    @Override
    public void options() {

    }
}
