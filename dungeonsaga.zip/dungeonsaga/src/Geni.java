public class Geni extends Jogador {

    String nome;

    //apresenta as características dos personagens
    //(nome, descrição, idade) e qual regra modifica.
    void contarHistoria(){

    }

    //mét0dos para reescrever a regra a
    //ser aplicada para o Jogador em questão.
    void adicionaRegra(){

    }
    void modificaRegra() {

    }
    void sorteiaRegra(){

    }

}
