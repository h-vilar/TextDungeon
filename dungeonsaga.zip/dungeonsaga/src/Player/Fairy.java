package Player;

import Enemies.Enemy;
import Text.Cores;
import Text.TextDungeon;

public class Fairy extends Jogador {

    public Fairy(int maxhp, String nome, int dano){
        this.DANO = dano;
        this.cor = Cores.ROSA;
        this.nome = nome;
        this.maxhp = maxhp;
        this.hp = maxhp;
        sinopse = "Uma alada e delicada criatura da floresta mágica, a Fada não é muito forte porém tem um" +
                "ótimo alcance contra qualquer inimigo e incríveis poderes de cura.\n\n";

    }

    //apresenta as características dos personagens
    //(nome, descrição, idade) e qual regra modifica.
    // (antigo contarHistoria()


    //mét0dos para reescrever a regra a
    //ser aplicada para o Player.Jogador em questão.
    void adicionaRegra(){

    }
    void modificaRegra() {

    }
    void sorteiaRegra(){

    }

    @Override
    public void habilidade1(Enemy enemy, Jogador aliado) { //cura

        passiva();
    }

    @Override
    public void habilidade2(Enemy enemy, Jogador aliado) { //upper homing   
        if(enemy.Airborne){
            enemy.hp-=10;
        }else{

        }
        passiva();
    }

    @Override
    public void habilidade3(Enemy enemy, Jogador aliado) { //lower homing
        if(!enemy.Airborne){

        }
        passiva();
    }

    @Override
    public void habilidade4(Enemy enemy, Jogador aliado) {

        passiva();
    }

    public void passiva(){

    }

    @Override
    public void options() {

       System.out.println(Cores.RESET);
        System.out.printf("Insira o número: O que a Fada fará?\n");
        System.out.println("   1. Curar Aliado");
        System.out.println("   2. Brilho Cintilante Acima");
        System.out.println("   3. Brilho Cintilante Abaixo");
        System.out.println("   4. Vinhas Pegajosas");
    }
}












