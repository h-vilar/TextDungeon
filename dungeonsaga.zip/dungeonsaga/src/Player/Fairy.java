package Player;

import Enemies.Enemy;
import Text.Cores;
import Text.TextDungeon;

public class Fairy extends Jogador {

    public Fairy(int maxhp, String nome){
        this.nome = nome;
        this.maxhp = maxhp;
        this.hp = maxhp;
        sinopse = "Uma alada e delicada criatura da floresta mágica, a Fada não é muito forte porém tem um" +
                "ótimo alcance contra qualquer inimigo e incríveis poderes de cura.\n\n";

    }

    //apresenta as características dos personagens
    //(nome, descrição, idade) e qual regra modifica.
    // (antigo contarHistoria()


    //mét0dos para reescrever a regra a
    //ser aplicada para o Player.Jogador em questão.
    void adicionaRegra(){

    }
    void modificaRegra() {

    }
    void sorteiaRegra(){

    }

    @Override
    public void habilidade1(Enemy enemy, Jogador aliado) { //cura

        passiva();
    }

    @Override
    public void habilidade2(Enemy enemy, Jogador aliado) { //upper homing   
        if(enemy.Airborne){
            enemy.hp-=10;
        }else{

        }
        passiva();
    }

    @Override
    public void habilidade3(Enemy enemy, Jogador aliado) { //lower homing
        if(!enemy.Airborne){

        }
        passiva();
    }

    @Override
    public void habilidade4(Enemy enemy, Jogador aliado) {

        passiva();
    }

    public void passiva(){

    }

    @Override
    public void options() {

    }
}
