package Player;

import Enemies.Enemy;
import Text.Cores;
import Text.TextDungeon;

public class Sasquatch extends Jogador {

    public Sasquatch(int maxhp, String nome, int dano){
        this.DANO = dano;
        this.cor = Cores.ROSA;
        this.maxhp = maxhp;
        this.nome = nome;
        this.hp = maxhp;
        sinopse = "um monstro gigante\n\n";
    }

    //apresenta as características dos personagens
    //(nome, descrição, idade) e qual regra modifica.


    //mét0dos para reescrever a regra a
    //ser aplicada para o Player.Jogador em questão.
    void adicionaRegra(){

    }
    void modificaRegra() {

    }
    void sorteiaRegra(){

    }

    @Override
    public void habilidade1(Enemy enemy, Jogador aliado) {

    }

    @Override
    public void habilidade2(Enemy enemy, Jogador aliado) {

    }

    @Override
    public void habilidade3(Enemy enemy, Jogador aliado) {

    }

    @Override
    public void habilidade4(Enemy enemy, Jogador aliado) {

    }


    @Override
    public void options() {

        System.out.println(Cores.RESET);
        System.out.printf("Insira o número: O que Sasquatch fará?\n");
        System.out.println("   1. Curar Aliado");
        System.out.println("   2. Brilho Cintilante Acima");
        System.out.println("   3. Brilho Cintilante Abaixo");
        System.out.println("   4. Vinhas Pegajosas");
    }
}
