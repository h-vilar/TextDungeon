package MainGame;

import Enemies.*;
import Player.*;
import Text.*;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static Scanner sc;
    private static void TextDungeon() {

        /* na hora de começar a batalha, um inimigo aleatorio da lista de inimigos vai ser
        selecionado. por isso que não pode adicionar o boss nessa lista; vai ter uma outra
        lista pra selecionar um dos bosses aleatoriamente na parte do gameloop que tiver
        que ser o boss.
         */
        ArrayList<Enemy> inimigos = new ArrayList<>();
        Kirin kirin = new Kirin();
        Succubus suc = new Succubus();
        //inimigos.add(kirin); //pra eu testar so a suc
        inimigos.add(suc);

        ArrayList<Jogador> herois = new ArrayList<>();
        Fairy fada =       new Fairy(100, "Fada");
        Sasquatch pe = new Sasquatch(100, "Sasquatch");
        Mermaid m =            new Mermaid(100, "Sereia");
        herois.add(fada);
        herois.add(pe);
        herois.add(m);

        // ^^^ pré configuração ^^^
        // texto e arte de intro

        //(deixar tudo amarelo pra depois ver as cores)
        System.out.println(Cores.AMARELO_intro);

        //antes/entre as batalhas, gostaria que o texto viesse lento
        //(uns 60 millis) para dar um contraste com a sensação de ação x calmaria.

        Historia.placeholder();
        TextDungeon.escrever(Historia.intro, 1);

        TextDungeon.escrever("   Player 1, escolha seu herói: \n\n\n", 10);
        for(int i = 0; i<herois.size(); i++){
            System.out.printf((i+1)+") ");
            TextDungeon.escrever(herois.get(i).nome, 10);
            System.out.printf("\n");
            TextDungeon.escrever(herois.get(i).sinopse, 10);
        }
        int n1 = opcao(1, herois.size());
        Jogador P1 = herois.remove(n1 - 1); // o jogador vê 1, 2, 3...; a lista começa em 0

        TextDungeon.escrever("\n   Player 2, escolha seu herói: \n\n\n", 10);
        for(int i = 0; i<herois.size(); i++){
            System.out.printf((i+1)+") ");
            TextDungeon.escrever(herois.get(i).nome, 10);
            System.out.printf("\n");
            TextDungeon.escrever(herois.get(i).sinopse, 10);
        }
        int n2 = opcao(1, herois.size());
        Jogador P2 = herois.remove(n2 - 1);


        TextDungeon.clean();

        //presumindo que seriam inimigos aleatórios; acho que agora quero fixos, pelomenos os 3 e 4
        Enemy Enemy1 = inimigos.remove(Jogo.criarNumeroAleatorio(inimigos.size()));

        TextDungeon.batalha(P1, P2, Enemy1); //1


















        System.out.printf("\n\n\nFim");
    }

    public static void main(String[] args) {

        //TextDungeon(); //pra provar que o console pane é apenas um capricho e o jogo é o mesmo sem ele

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("TextDungeon");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(new ConsolePane());
            frame.setSize(900, 1000);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            new Thread(Main::TextDungeon).start();
        });

    }


    public static int opcao(int min, int max) { /** Lê um número de min a max (inclusive). Repete até o jogador digitar algo válido. */
        if (sc == null) sc = new Scanner(System.in);   // criado só no primeiro uso
        while (true) {
            String linha = sc.nextLine().trim();
            try {
                int n = Integer.parseInt(linha);
                if (n >= min && n <= max) {
                    System.out.flush();
                    return n;
                }
            } catch (NumberFormatException e) { }
            System.out.println("Escolha uma das opções! (de " + min + " a " + max + ".)");
        }
    }


    /*Inicialização: Com as classes base criadas, podemos programar o jogo! No início
    do programa, chame o mét0do iniciarJogo(). Esse mét0do deve definir o
    número de jogadores, que corresponde ao tamanho do ArrayList retornado. Em
    seguida, ainda no mét0do iniciarJogo(), exiba na tela uma mensagem de
    boas-vindas, apresentando o nome, idade, descrição e a regra modificada de cada
    personagem por meio do mét0do contarHistoria() definido na classe de cada
    Personagem. Por fim, permita que cada jogador escolha um personagem exclusivo,
    utilizando o mét0do setPersonagem(), e instancie cada personagem selecionado.

    Finalização: Quem ganhou? Determine o vencedor com base nos dados de
    pontuacao() e exiba a mensagem apropriada para cada possível final.*/
}