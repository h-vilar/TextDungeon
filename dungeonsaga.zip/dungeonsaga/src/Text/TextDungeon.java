package Text;

import Enemies.Enemy;
import MainGame.Jogo;
import MainGame.Main;
import Player.Jogador;
import java.util.ArrayList;
import Text.Cores;

public class TextDungeon implements Jogo {

    public static void batalha(Jogador P1, Jogador P2, Enemy Enemy){

        boolean batalha = true;
        boolean inicio = true;

        //começar ost aqui e...
        while(batalha){

            TextDungeon.clean();
            //System.out.printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            //System.out.flush();

            //barras dos players. do 1
            System.out.println();
            for(int k = 0; k<P1.hp; k++){
                try{Thread.sleep(20);}catch(Exception e){}
                System.out.printf(P1.cor);
                System.out.printf("\r  [P1] %s %d/%d ",P1.nome,k+1,P1.maxhp);
                //System.out.printf("\r                     ");
            }
            for(int k = 0; k<P1.hp; k++){
                try{Thread.sleep(20);}catch(Exception e){}
                System.out.printf("█");
            }
            System.out.printf("\n\n");
            
            //do 2 (transformar ambas em metodo)
            for(int k = 0; k<P2.hp; k++){
                try{Thread.sleep(20);}catch(Exception e){}
                System.out.printf(P2.cor);
                System.out.printf("\r  [P2] %s %d/%d ",P2.nome,k+1,P2.maxhp);
                //System.out.printf("\r                     ");
            }
            for(int k = 0; k<P1.hp; k++){
                try{Thread.sleep(20);}catch(Exception e){}
                System.out.printf("█");
            }
            
            
            
            
            
            if(inicio) {
                
                Enemy.Art();
                Enemy.intro(); inicio = false;
            } else {
                Enemy.Art();
                //trocar esse switch pra um check da variavel
                //STATE: se for tal ou tal, botar arte/desc tal.
                //esse art de cima ta errado supostamente.
                switch (Jogo.criarNumeroAleatorio(2)){
                    case 0:
                        Enemy.state1(); break;
                    case 1:
                        Enemy.state2(); break;
                    case 2:
                        Enemy.state3(); break;
                }
            }



            //loopzinho demo barra de hp
            System.out.printf("\n\n");
            int hpteste = 42;
            for(int k = 0; k<hpteste; k++){
                try{Thread.sleep(20);}catch(Exception e){}
                System.out.printf("\r  ♥ SUCCUBUS ♥ %d/%d ", k+1, hpteste);
                //System.out.printf("\r                     ");
            }
            for(int k = 0; k<hpteste; k++){
                try{Thread.sleep(20);}catch(Exception e){}
                System.out.printf("█");
            }
            System.out.printf("\n\n");




            P1.options();
            int n1 = Main.opcao(1, 5);
            switch (n1){
                case 1:
                    P1.habilidade1(Enemy, P2);
                    break;
                case 2:
                    P1.habilidade2(Enemy, P2);
                    break;
                case 3:
                    P1.habilidade3(Enemy, P2);
                    break;
                case 4:
                    P1.habilidade4(Enemy, P2); break;
            }
            
            if(Enemy.hp<=0){ //primeiro checar se morreu; dps continua
                //...?
                Enemy.death();
                batalha = false;
            }

            TextDungeon.clean();
            
            //mostrar denovo aqui: hpbar e art e desc do inimigo
            //só que agora aplicada alguma coisa sobre as opçoes do p1..
            
            //if tipo o de lá de cima; perguntando o state e
            //depende do state a art e desc que aparecem aqui nessa parte.


            P2.options();
            int n2 = Main.opcao(1, 5);
            switch (n2){
                case 1:
                    P2.habilidade1(Enemy, P1); break;
                case 2:
                    P2.habilidade2(Enemy, P1); break;
                case 3:
                    P2.habilidade3(Enemy, P1); break;
                case 4:
                    P2.habilidade4(Enemy, P1); break;
            }

            if(Enemy.hp<=0){
                //...
                Enemy.death();
                batalha = false;
            }

            //enemy atk
            switch (Jogo.criarNumeroAleatorio(2)){
                case 0:
                    Enemy.ATTACK1(P1, P2); break;
                case 1:
                    Enemy.ATTACK2(P1, P2); break;
                case 2:
                    Enemy.ATTACK3(P1, P2); break;
            }

            if(P1.hp<=0&&P2.hp<=0){
                TextDungeon.GameOver();
            }

        }
    }


    public static void escrever(String texto, long millis){ //maquina de escrever
        for (Character c : texto.toCharArray()) {
            System.out.print(c);
            if (!Character.isWhitespace(c)) {
                try {
                    Thread.sleep(millis); //5,10,20,30 são bons
                } catch (Exception e) {}
            }
        }
    }

    public static void clean() {
        System.out.print("\033[H\033[2J"); System.out.flush();}

    public static void GameOver(){

    }
































    @Override
    public void jogarTurno(Jogador jogador) {
    }

    @Override
    public ArrayList<Jogador> iniciarjogo() {
        return null;
    }

    @Override
    public boolean jogoAcabou() {
        return false;
    }

    //ughhhhhh.
    void pontuacao(){}

}
