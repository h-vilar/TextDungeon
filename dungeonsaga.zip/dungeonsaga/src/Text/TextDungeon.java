package Text;

import Enemies.Enemy;
import MainGame.Jogo;
import MainGame.Main;
import Player.Jogador;
import java.util.ArrayList;
import Text.Cores;

public class TextDungeon implements Jogo {

    public static void batalha(Jogador P1, Jogador P2, Enemy Enemy){

        boolean batalha = true;
        boolean inicio = true;

        //começar ost aqui e...
        while(batalha){

            TextDungeon.clean();
            //System.out.printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            //System.out.flush();
            hpbars(P1, P2);
            
            if(inicio) {
                
                Enemy.Art();
                Enemy.intro(); inicio = false;
            } else {
                Enemy.Art();
                //trocar esse switch pra um check da variavel
                //STATE: se for tal ou tal, botar arte/desc tal.
                //esse art de cima ta errado supostamente.
                switch (Jogo.criarNumeroAleatorio(2)){
                    case 0: Enemy.state1(); break;
                    case 1: Enemy.state2(); break;
                    case 2: Enemy.state3(); break;
                }
            }


            //enemy hp bar
            enemyhpbar(Enemy);


            P1.options();
            int n1 = Main.opcao(1, 5);
            switch (n1){
                case 1: P1.habilidade1(Enemy, P2);break;
                case 2: P1.habilidade2(Enemy, P2);break;
                case 3: P1.habilidade3(Enemy, P2);break;
                case 4: P1.habilidade4(Enemy, P2);break;
            }
            
            if(Enemy.hp<=0){ //primeiro checar se morreu; dps continua
                //...?
                Enemy.death();
                batalha = false;
            }

            //ja apareceu as barras pois estao nas skills (o clean tb), ent...
            Enemy.Art();
            Enemy.intro(); // dnv, mas tem q ser outra coisa...
            enemyhpbar(Enemy);
            
            //mostrar denovo aqui: hpbar e art e desc do inimigo
            //só que agora aplicada alguma coisa sobre as opçoes do p1..
            
            //if tipo o de lá de cima; perguntando o state e
            //depende do state a art e desc que aparecem aqui nessa parte.


            P1.options(); //botei p1 options aqui só pq n escrevi ainda a de nenhum outro heroi e quero vizualizar.
            int n2 = Main.opcao(1, 5);
            switch (n2){
                case 1: P2.habilidade1(Enemy, P1); break;
                case 2: P2.habilidade2(Enemy, P1); break;
                case 3: P2.habilidade3(Enemy, P1); break;
                case 4: P2.habilidade4(Enemy, P1); break;
            }

            if(Enemy.hp<=0){
                //...
                Enemy.death();
                batalha = false;
            }

            //enemy atk
            switch (Jogo.criarNumeroAleatorio(2)){
                case 0: Enemy.ATTACK1(P1, P2); break;
                case 1: Enemy.ATTACK2(P1, P2); break;
                case 2: Enemy.ATTACK3(P1, P2); break;
            }

            if(P1.hp<=0&&P2.hp<=0){
                TextDungeon.GameOver();
            }

        }
    }

    public static void deathcheck(Enemy Enemy){ //precisa ss ou nn?

    }

    public static void hpbars(Jogador P1, Jogador P2){
        //barras dos players. do 1
        System.out.println();
        for(int k = 0; k<P1.hp; k++){
            System.out.printf(P1.cor);
            System.out.printf("\r  [P1] %s %d/%d ",P1.nome,k+1,P1.maxhp);
            //System.out.printf("\r                     ");
        }
        System.out.printf("░▒▓");
        for(int k = 0; k<P1.hp; k++){

            System.out.printf("█");
        }
        System.out.printf("▓▒░");
        System.out.printf("\n\n");
        for(int k = 0; k<P2.hp; k++){

            System.out.printf(P2.cor);
            System.out.printf("\r  [P2] %s %d/%d ",P2.nome,k+1,P2.maxhp);
        }
        System.out.printf("░▒▓");
        for(int k = 0; k<P2.hp; k++){
            System.out.printf("█");
        }
        System.out.printf("▓▒░");
    }

    public static void enemyhpbar(Enemy enemy){
        //loopzinho demo barra de hp
        System.out.printf("\n\n");
        System.out.printf(Cores.MAGENTA_BRILHANTE);
        for(int k = 0; k<enemy.hp; k++){
            try{Thread.sleep(20);}catch(Exception e){}
            System.out.printf("\r  %s %d/%d ", enemy.nome, k+1, enemy.maxhp);
            //System.out.printf("\r                     ");
        }
        System.out.printf("░▒▓");
        for(int k = 0; k<enemy.hp; k++){
            try{Thread.sleep(20);}catch(Exception e){}
            System.out.printf("█");
        }
        System.out.printf("▓▒░");
        System.out.printf("\n\n");
    }

    public static void escrever(String texto, long millis){ //maquina de escrever
        for (Character c : texto.toCharArray()) {
            System.out.print(c);
            if (!Character.isWhitespace(c)) {
                try {
                    Thread.sleep(millis); //5,10,20,30 são bons
                } catch (Exception e) {}
            }
        }
    }

    public static void clean() {
        System.out.print("\033[H\033[2J"); System.out.flush();}

    public static void GameOver(){

    }
































    @Override
    public void jogarTurno(Jogador jogador) {
    }

    @Override
    public ArrayList<Jogador> iniciarjogo() {
        return null;
    }

    @Override
    public boolean jogoAcabou() {
        return false;
    }

    //ughhhhhh.
    void pontuacao(){}

}
