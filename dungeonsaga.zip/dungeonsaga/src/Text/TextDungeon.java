package Text;

import Enemies.Enemy;
import MainGame.Jogo;
import MainGame.Main;
import Player.Jogador;
import java.util.ArrayList;

public class TextDungeon implements Jogo {

    public static void batalha(Jogador P1, Jogador P2, Enemy Enemy){

        boolean batalha = true;
        boolean inicio = true;

        //começar ost aqui e...
        while(batalha){

            TextDungeon.clean();
            //System.out.printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            //System.out.flush();

            if(inicio) {
                Enemy.Art();
                Enemy.intro(); inicio = false;
            } else {
                Enemy.Art();
                //enemy state
                switch (Jogo.criarNumeroAleatorio(2)){
                    case 0:
                        Enemy.state1(); break;
                    case 1:
                        Enemy.state2(); break;
                    case 2:
                        Enemy.state3(); break;
                }
            }



            //loopzinho demo barra de hp
            System.out.printf("\n\n");
            int hpteste = 42;
            for(int k = 0; k<hpteste; k++){
                try{Thread.sleep(70);}catch(Exception e){}
                System.out.printf("\r  ♥ SUCCUBUS ♥ %d/%d ", k+1, hpteste);
                //System.out.printf("\r                     ");
            }
            for(int k = 0; k<hpteste; k++){
                try{Thread.sleep(70);}catch(Exception e){}
                System.out.printf("█");
            }
            System.out.printf("\n\n");




            P1.options();
            int n1 = Main.opcao(1, 5);
            switch (n1){
                case 1:
                    P1.habilidade1(Enemy, P2);
                    break;
                case 2:
                    P1.habilidade2(Enemy, P2);
                    break;
            }

            if(Enemy.hp<=0){
                //...
                Enemy.death();
                batalha = false;
            }

            P2.options();
            int n2 = Main.opcao(1, 5);
            switch (n2){
                case 1:
                    P2.habilidade1(Enemy, P1); break;
                case 2:
                    P2.habilidade2(Enemy, P1); break;
            }

            if(Enemy.hp<=0){
                //...
                Enemy.death();
                batalha = false;
            }

            //enemy atk
            switch (Jogo.criarNumeroAleatorio(2)){
                case 0:
                    Enemy.ATTACK1(P1, P2); break;
                case 1:
                    Enemy.ATTACK2(P1, P2); break;
                case 2:
                    Enemy.ATTACK3(P1, P2); break;
            }

            if(P1.hp<=0&&P2.hp<=0){
                TextDungeon.GameOver();
            }

        }
    }


    public static void escrever(String texto, long millis){ //maquina de escrever
        for (Character c : texto.toCharArray()) {
            System.out.print(c);
            if (!Character.isWhitespace(c)) {
                try {
                    Thread.sleep(millis); //5,10,20,30 são bons
                } catch (Exception e) {}
            }
        }
    }

    public static void clean() {
        System.out.print("\033[H\033[2J"); System.out.flush();}

    public static void GameOver(){

    }
































    @Override
    public void jogarTurno(Jogador jogador) {
    }

    @Override
    public ArrayList<Jogador> iniciarjogo() {
        return null;
    }

    @Override
    public boolean jogoAcabou() {
        return false;
    }

    //ughhhhhh.
    void pontuacao(){}

}
