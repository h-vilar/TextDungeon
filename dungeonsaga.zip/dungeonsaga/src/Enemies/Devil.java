package Enemies;

import Player.Jogador;

public class Devil extends Enemy {

    public Devil(int maxhp, String nome, int dano){
        this.maxhp = maxhp;
        this.nome = nome;
        this.DANO = dano;
    }

    @Override
    public void intro() {

    }

    @Override
    public void death() {

    }

    @Override
    public void Art() {

    }

    @Override
    public void ATTACK1(Jogador p1, Jogador p2) {

    }

    @Override
    public void ATTACK2(Jogador p1, Jogador p2) {

    }

    @Override
    public void ATTACK3(Jogador p1, Jogador p2) {

    }

    @Override
    public void state1() {

    }

    @Override
    public void state2() {

    }

    @Override
    public void state3() {

    }
}
