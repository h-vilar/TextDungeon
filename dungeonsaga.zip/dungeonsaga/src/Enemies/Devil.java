package Enemies;

import Player.Jogador;

public class Devil extends Enemy {

    @Override
    public void intro() {

    }

    @Override
    public void death() {

    }

    @Override
    public void Art() {

    }

    @Override
    public void ATTACK1(Jogador p1, Jogador p2) {

    }

    @Override
    public void ATTACK2(Jogador p1, Jogador p2) {

    }

    @Override
    public void ATTACK3(Jogador p1, Jogador p2) {

    }

    @Override
    public void state1() {

    }

    @Override
    public void state2() {

    }

    @Override
    public void state3() {

    }
}
