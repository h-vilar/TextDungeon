package Enemies;

import Player.Jogador;
import Text.Cores;
import Text.TextDungeon;

public class Succubus extends Enemy {
    
    public final int maxhp = 100;
    int hp = maxhp;

    static long drama = 10; //tempo pras descrições desse inimigo escreverem.

    public boolean Airborne = true; //se é aéreo ou está no ar agora~
    boolean Waterlog = false; //se está na água ou molhado agora~

    boolean Fiery = false;
    boolean Fragile = false; //+ afetado por tremor
    boolean Reflexive = false; //anti-projétil
    boolean Toxic = false; //anti-melee
    boolean AntiPhysic = false; //imune a dano físico
    boolean AntiMagic = true; //imune a dano mágico

    @Override
    public void ATTACK1(Jogador p1, Jogador p2){

    }
    @Override
    public void ATTACK2(Jogador p1, Jogador p2){

    }
    @Override
    public void ATTACK3(Jogador p1, Jogador p2){

    }

    @Override
    public void state1(){ //igual inicio?

    }
    @Override
    public void state2(){ //no chão?

    }
    @Override
    public void state3(){ //carregando?

    }

    @Override
    public void intro(){ //ajustand0
        String desc = Cores.MAGENTA+"       Ooh, isso vai ter DIVERTIDO! Faz tempo que eu não me divirto com duas presas frescas ao mesmo tempo :3\n" +
                "     Deixe me ver -- é uma pena o fato de vocês parecerem super inexperientes... que caras são essas? Ora, NUNCA VIRAM UMA MULHER ALADA?" +
                "\n     Mas não se preocupem, não é de todo mal - nem fico com raiva! É até interessante pra mim ver as reações de quem nunca... experimentou nada..." +
                "\n\n               Então um de cada vez, VAMOS COMEÇAR!"+Cores.MAGENTA_BRILHANTE;

        TextDungeon.escrever(desc, drama);
    }

    @Override
    public void death() {

    }
    
    @Override
    public void Art(){ //pequena pra testa no cel; 50 linhas
        System.out.println(Cores.MAGENTA_BRILHANTE);
                System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡤⢦⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠎⠰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠜⠁⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⢤⡪⣮⠋⠀⠀⠀⠀⠀⠫⡉⢣⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡴⣞⡽⣳⢝⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⡾⣶⢶⣴⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⣠⢾⡽⣞⡽⣺⢗⣽⠀⠀⠀⢤⣀⠀⠀⠀⠀⠀⠀⠀⠈⢿⣻⣞⣷⡽⣯⣻⣟⣶⣢⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⢠⣾⣝⣯⡻⣮⢯⡻⣵⡯⠀⢠⣙⠶⢄⠹⡄⠀⠀⠀⠀⠀⠀⠈⢷⡻⣾⢽⣷⣻⣞⣷⣻⣞⡿⣦⡄⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⣴⣻⣞⡷⣽⢯⡳⣯⡻⣼⣗⠀⢕⠅⠤⠠⢫⡚⠀⣀⡀⠀⠀⠀⠀⠸⣯⣻⢷⣝⢿⣞⣷⣻⣞⣿⣽⣻⣗⣄⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⢀⣾⡽⣷⢽⡯⣿⣝⢿⣮⣻⣗⢿⠀⡀⣷⢄⣒⣼⣒⣞⡽⠙⣦⡀⠀⠀⠰⣯⢿⡽⣯⣻⣞⣷⣻⣞⣷⣻⣷⣻⢾⣧⡀⠀⠀⠀⠀");
        System.out.println("⠀⢀⣾⣳⢿⡽⣯⢿⣮⣻⣗⢷⡽⡯⣻⢧⡫⣾⣝⣭⠓⡽⣮⣹⡻⣷⣻⣖⢶⡺⡝⣣⣽⡳⣿⢮⡟⣷⣻⣞⡷⣯⢿⣯⣿⣽⣆⠀⠀⠀");
        System.out.println("⠀⣼⢾⣽⢯⡿⣽⣳⣟⣮⢿⣝⡿⣽⢯⡾⣝⡿⣼⣫⣟⢿⣞⣮⣟⢷⡽⣫⢟⡴⣫⢷⡽⣯⣻⢿⠀⠸⣷⢯⡿⣽⣟⡾⣷⢿⣾⣆⠀⠀");
        System.out.println("⢰⣻⣗⡿⣯⣻⣗⣿⣺⣗⣿⣺⣯⣻⢗⣿⣻⢞⡮⣳⢻⢯⡿⣮⣟⣗⢙⡵⣫⢾⢏⡾⣽⢷⣯⡟⠀⠀⢻⣯⣟⡷⣿⣽⣻⣟⣾⣻⡆⠀");
        System.out.println("⣼⢷⡿⣽⢯⣷⣻⣞⣷⣻⣞⢷⡯⣿⣝⣯⢯⣻⠝⠙⠁⠫⣏⣾⣽⢫⣞⢽⣽⡛⣾⣝⣿⣳⢿⣦⣤⣤⣘⡷⣿⡽⣷⢯⣿⣽⣯⣟⣿⠀");
        System.out.println("⣟⣿⣻⣟⣿⣞⣷⣻⣞⣷⣝⣿⣻⣞⡷⣽⢯⠃⠀⠀⠀⢘⡧⣻⢕⢧⣻⣟⣾⢯⡷⣽⢾⣯⢿⡾⣷⢿⣞⢿⣽⣻⣟⡿⣾⢷⣿⠈⢿⡃");
        System.out.println("⢿⣽⣯⢿⡾⣽⢷⡿⣞⣷⣻⢾⡷⣽⣯⣻⡃⠀⠀⠀⠀⣸⣝⢎⡷⣫⣾⣽⣟⡷⣻⣽⢿⣽⣟⣿⠻⠋⠉⠘⣷⣻⣞⣿⣻⣯⡟⠀⠀⡃");
        System.out.println("⢺⣷⣟⡟⢻⣻⣟⣿⣽⣯⣟⣿⣿⡘⢷⢿⠄⠀⠀⠀⢰⠋⢺⡽⣽⢷⡿⠞⠋⢻⣽⣟⡿⡓⠉⠀⠀⠀⠀⠀⣿⣽⣯⣿⣳⢿⠇⠀⠀⠀");
        System.out.println("⠀⢿⣽⡇⠀⠙⢽⡷⣿⣾⣻⡷⣿⣇⠀⠙⠆⠀⠀⠀⡏⠀⠀⠈⠉⠉⠀⣰⣟⣿⡾⠉⠨⣲⠀⠀⠀⠀⠀⠀⢼⡷⣿⣾⣻⡿⠀⠀⠀⠀");
        System.out.println("⠀⠘⣷⡁⠀⠀⠀⠻⡿⣾⣯⣿⣯⣿⡄⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⢠⡾⢯⣿⣽⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣟⣿⣾⣻⠃⠀⠀⠀⠀");
        System.out.println("⠀⠀⠸⡆⠀⠀⠀⠀⠈⠻⣾⢷⡿⣾⣷⡀⠀⠀⠀⠀⠱⠀⠀⠀⠀⠁⠀⢰⡿⡞⢀⡠⠤⠒⠒⠢⢄⠀⠀⠀⢸⣟⣷⣿⠁⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⢁⠀⠀⠀⠀⠀⠀⠈⠻⣻⡿⣾⢷⡄⠀⠀⠀⠀⠑⠤⣀⣀⣀⡀⣿⡟⠊⠁⠀⠀⠀⠀⠀⠀⢥⠀⠀⣽⣟⣷⠃⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣻⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠃⠀⠀⠀⠀⠀⠀⠀⡰⠃⠀⢀⣿⡽⠃⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠑⠿⣦⡀⠀⠀⠀⠀⠀⠀⠀⣠⠆⠀⠀⢀⣀⡠⠔⠊⠀⠀⠀⣸⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣄⠀⠀⠀⠀⢀⣾⣻⡿⣯⡍⠉⠀⠀⠀⠀⠀⠀⠀⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠳⣄⠀⠀⠘⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");                    
    
         }

         //@Override
    public void Art2(){ //70 linhas
        System.out.println(Cores.MAGENTA_BRILHANTE);
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡞⢹⣳⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡴⠋⠠⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡠⣰⢖⠞⠀⠀⠀⠀⠀⠀⠠⡾⠶⣤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⣚⡵⣫⢧⠏⠀⠀⠀⠀⠀⠀⠀⠀⠙⠇⠈⠳⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡴⣞⡽⣮⡻⣞⣕⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢻⡻⡷⣶⢶⢶⡦⣦⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⢾⣝⡾⣝⣟⢮⡻⡮⣾⠁⠀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣽⣻⢯⣿⡺⣷⣽⣻⣟⣶⣤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⣝⣷⡻⣞⢷⡽⣝⣯⢺⣟⠀⠀⢀⢴⣉⢋⠓⢤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⣻⢷⣯⣻⢷⣻⣞⣷⣻⡮⣿⣝⡿⣦⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⣠⣞⣿⣺⣟⣮⣟⣽⣳⡻⣞⢮⡿⣇⠀⠀⡧⡪⠝⠝⠦⢢⢯⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⡻⣾⡽⣯⣟⢾⡷⣽⡻⣾⣝⣿⣳⣯⢿⣦⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⢀⣴⣟⣾⣳⣟⣾⣳⢽⡮⣷⢽⣝⣷⣻⣇⠠⢘⠼⡁⣤⠄⠨⢇⡳⡍⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⢹⣻⣗⢿⡾⣽⢯⡿⣽⣻⣗⣿⣞⣷⣻⣟⣾⣻⢷⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⢠⣾⣳⣟⣾⣳⣟⣮⣻⣗⢿⡺⡷⣽⣞⢷⣯⠀⠀⠩⣆⢄⠀⣔⢸⣕⣁⡴⣞⡽⢳⡄⠀⠀⠀⠀⠀⢠⣟⢾⡯⣿⡽⣯⢿⡽⣷⣻⣞⣿⣞⣷⣻⢾⣽⣻⣟⣷⡀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⢠⡿⣞⣷⣻⣞⣷⣻⣞⢷⣽⣫⣟⡽⣮⣟⣷⣻⡄⡣⢮⣮⣹⣖⢶⡫⣾⡲⣿⣜⣃⡘⡿⣦⡀⠀⠀⠀⣰⣯⣻⡻⣞⢯⡿⣽⣯⣻⣷⣻⣞⡿⣾⣽⣻⢷⣯⣿⡽⣿⣦⡀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⢠⡿⣽⣻⣞⣷⣻⣞⡷⣽⣳⣟⣮⢗⣿⣺⣟⢮⡻⡷⣝⢮⡾⣮⡳⣝⡍⣫⢻⡮⣮⣝⣽⣻⢾⣝⣟⣟⣟⢷⡫⣪⡵⣽⢯⣟⣾⣳⣟⠺⣷⢯⣟⡷⣯⣟⡿⣾⢷⣻⣷⣻⣷⡄⠀⠀⠀⠀");
        System.out.println("⠀⢀⣿⡽⣯⢿⣞⣷⣻⣞⣿⣺⣗⣿⡺⣯⢞⣷⣻⣗⢯⢾⡼⣯⢿⣮⡻⣗⣿⣺⣟⡷⣝⣾⣳⢯⡿⣽⡻⡾⡕⣷⢺⣵⢻⣞⣷⣻⣞⢷⡏⠀⠹⣯⢿⡽⣷⢯⣿⣽⣻⣷⣻⣷⣻⣿⣄⠀⠀⠀");
        System.out.println("⠀⣼⢷⡿⣽⢯⡿⣞⣷⣻⣞⣷⡻⣮⢿⣝⢿⡷⣽⣯⣻⣳⣟⣾⡳⣝⢯⣟⡾⣷⢯⣟⢿⣞⣿⣳⡻⣮⡻⣵⡻⣪⢷⣏⡿⣺⢷⡽⣯⣻⠇⠀⠀⢻⣯⣿⣽⣻⣞⡷⣿⢾⣷⣻⢷⣯⣿⡄⠀⠀");
        System.out.println("⢰⣟⣯⣻⣯⢿⣽⣻⣞⣷⣻⢮⡿⣝⢷⣯⣻⣟⢾⡷⣽⢯⡿⣮⡻⣮⣳⣎⣟⢽⣯⢿⣝⡿⣾⢧⡌⣸⡞⣵⣝⣿⢣⣟⢽⣯⢿⣝⣷⡻⠀⠀⠀⠘⣷⢿⣞⡷⣯⣟⣿⣻⣷⣻⣟⣾⡽⣷⡀⠀");
        System.out.println("⣸⣟⡾⣷⣻⣟⣾⣳⢿⡮⣿⢽⣯⡻⣷⢽⡷⣯⢿⡽⣯⣟⢿⣮⡻⡾⠕⠉⠈⢰⢝⡧⣻⡽⣯⢟⡴⣯⡺⣞⡷⣯⣳⣝⣷⣻⣟⣾⣽⣧⣤⣤⣤⣀⣻⣯⢿⡽⣷⢯⣿⣳⣯⣿⣽⣞⣿⣽⣇⠀");
        System.out.println("⣿⡽⣿⣽⣯⢿⡾⣯⢿⣽⡻⣷⢯⡿⣽⢯⣿⡽⣯⣻⣮⡻⣷⢽⠏⠀⠀⠀⠀⠀⢮⡳⣝⣿⡣⣟⢺⡮⣿⣽⣻⢧⡿⣼⢷⣯⡿⣾⢷⡿⣾⣳⣯⣟⣷⣟⣿⣻⣽⣻⢷⡿⣾⢷⡿⣞⠳⢯⣿⠀");
        System.out.println("⣿⣻⡿⣾⣯⣟⣿⣻⣟⣾⣻⡽⣯⢿⣽⣳⣟⣿⡺⣷⢽⣯⣻⠇⠀⠀⠀⠀⠀⠀⣿⡱⣟⢼⡣⣯⣺⣻⢷⣿⣽⡳⣟⣾⣻⣾⣻⣟⣿⢿⡽⣷⢿⡾⠓⢿⡽⣷⢯⣟⣿⣻⣟⣿⣻⡏⠀⠀⢿⠄");
        System.out.println("⢹⣯⣿⣻⡾⣽⣯⣿⣽⣯⣿⣽⣯⢿⣞⣷⢯⣿⣝⣿⣳⡯⡷⠀⠀⠀⠀⠀⠀⢠⡿⣜⢧⡳⣝⣮⢷⣻⣟⣷⢿⣯⣟⡾⣷⢿⣽⣯⣿⡻⠟⠋⠁⠀⠀⠸⣿⡽⣯⣿⣽⣯⣿⣽⣻⡇⠀⠀⠈⠇");
        System.out.println("⠸⣷⢿⣽⣟⠟⢾⡷⣿⢾⡷⣿⢾⣯⣿⣽⢿⣾⡅⠻⣞⣿⡏⠀⠀⠀⠀⠀⢀⡟⠙⣞⡷⣻⢮⡿⣯⣿⠽⠻⠛⢪⣿⣽⣟⣿⡳⠛⠈⠀⠀⠀⠀⠀⠀⠀⣿⡽⣷⢿⡾⣷⢿⣞⣿⠀⠀⠀⠀⠁");
        System.out.println("⠀⢿⣻⡷⣿⠁⠀⠻⣟⣿⣻⣟⣿⢾⣷⣟⣿⣽⣷⠀⠉⠾⣯⠀⠀⠀⠀⠀⣼⠁⠀⠈⠙⠫⠻⠙⠓⠁⠀⣶⢷⡾⣷⡟⠙⠜⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⢽⣟⣿⣻⣟⣿⣯⣿⠇⠀⠀⠀⠀⠀");
        System.out.println("⠀⠈⣿⣻⡏⠀⠀⠀⠘⢯⣿⣽⣟⣿⢷⡿⣷⢿⣾⡆⠀⠀⠈⠀⠀⠀⠀⠀⡏⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⣻⣟⣿⣿⠁⠀⠈⠓⠋⠀⠀⠀⠀⠀⠀⠀⠀⢸⣯⣿⣽⣟⣷⣟⡿⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠸⣿⡇⠀⠀⠀⠀⠀⠙⢾⣯⣿⣻⣟⣿⢿⣽⣿⡀⠀⠀⠀⠀⠀⠀⠀⣏⠀⠀⠀⠀⠀⠀⢠⡿⠯⢻⣽⣟⣷⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡷⣿⢾⣯⣿⡽⠁⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⢹⣇⠀⠀⠀⠀⠀⠀⠈⠳⢿⣽⣯⣿⣻⡷⣿⣷⡀⠀⠀⠀⠀⠀⠀⢹⡀⠀⠀⠀⠀⠀⠉⠀⠀⢨⡷⣿⡏⠀⢀⣀⣠⠤⠤⠤⠤⣄⡀⠀⠀⠀⠀⢸⣟⣿⣻⡷⣿⠁⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⢳⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢿⣽⣟⣿⣻⡾⣷⡀⠀⠀⠀⠀⠀⠀⠱⣄⠀⠀⠀⠀⠀⠀⢀⣾⣻⡿⠤⠚⠉⠁⠀⠀⠀⠀⠀⠀⠙⡄⠀⠀⠀⢸⣯⣿⣽⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢯⣿⣽⣟⣿⣷⡀⠀⠀⠀⠀⠀⠀⠈⠑⠦⠤⠤⠤⠦⠚⣯⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡟⠀⠀⠀⣽⢷⡿⡾⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠳⢿⣷⣟⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡼⠁⠀⠀⢀⣿⣻⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⢽⡿⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡤⠀⠀⠀⠀⠀⠀⠀⣀⣠⠞⠋⠀⠀⠀⠀⣸⣯⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⢿⣆⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣅⣤⣤⣤⠴⠶⠚⠋⠉⠀⠀⠀⠀⠀⠀⢀⣿⡞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢷⣄⠀⠀⠀⠀⠀⢀⣾⢷⣿⣽⠷⠷⠦⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢷⡄⠀⠀⠀⠸⠋⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
   
    }
}