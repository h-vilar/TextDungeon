import javax.swing.*;

public class Main {

    static void TextDungeon() {

        Demo.demo(); //ainda to editando as coisas dentro do demo que é mais rapido,
        //mas já já ponho o real inicio aqui (classe historia.art, .intro, e aí o menu de escolha de personagens.)

        /*em algum lugar, vai ficar uma coisa tipo:
        (dentro da função de batalha)

        TextDungeon.escrever(Enemy.intro, Enemy.drama);


         */

    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("TextDungeon");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(new ConsolePane());
            frame.setSize(900, 1000);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            //thread separada p/ não travar a EDT
            new Thread(Main::TextDungeon).start();
        });

        //Demo.demo(); caso teste no terminal e nao acima
    }


    /*Inicialização: Com as classes base criadas, podemos programar o jogo! No início
    do programa, chame o mét0do iniciarJogo(). Esse mét0do deve definir o
    número de jogadores, que corresponde ao tamanho do ArrayList retornado. Em
    seguida, ainda no mét0do iniciarJogo(), exiba na tela uma mensagem de
    boas-vindas, apresentando o nome, idade, descrição e a regra modificada de cada
    personagem por meio do mét0do contarHistoria() definido na classe de cada
    Personagem. Por fim, permita que cada jogador escolha um personagem exclusivo,
    utilizando o mét0do setPersonagem(), e instancie cada personagem selecionado.

    Finalização: Quem ganhou? Determine o vencedor com base nos dados de
    pontuacao() e exiba a mensagem apropriada para cada possível final.*/
}